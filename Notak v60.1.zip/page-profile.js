// Profile Display Logic
function checkProfile() {
  const container = document.getElementById('profileDetails');
  container.classList.remove('hide');
  container.style.display = 'flex';
  setTimeout(() => {
    container.classList.add('show');
  }, 10);
}

function closeProfile() {
  const container = document.getElementById('profileDetails');
  container.classList.remove('show');
  container.classList.add('hide');
  setTimeout(() => {
    container.style.display = 'none';
  }, 600);
}

// Attach check/open listeners
document.getElementById("checkProfile").addEventListener("click", checkProfile);
document.getElementById("closeProfile").addEventListener("click", closeProfile);

// Firebase Auth Check
firebase.auth().onAuthStateChanged(user => {
  if (user) {
    const uid = user.uid;

    db.collection("users").doc(uid).get()
      .then(doc => {
        if (doc.exists) {
          const data = doc.data();

          document.getElementById("sub").innerText = `${data.storeName}`;
          document.getElementById("FullNameEdit").value = data.fullName || "";
          document.getElementById("StoreNameEdit").value = data.storeName || "";
          document.getElementById("UserNameEdit").value = data.userName || "";
          document.getElementById("EmailEdit").value = data.email || "";

        } else {
          alert("❌ No user data found.");
        }
      })
      .catch(error => {
        console.error("Error retrieving user data:", error);
        alert("❌ Error fetching user info.");
      });
  } else {
    alert("⛔ You are not logged in!");
    window.location.href = "login.html";
  }
});

// Update Profile Info
document.getElementById("updateDetails").addEventListener("click", () => {
  const fullName = document.getElementById("FullNameEdit").value.trim();
  const storeName = document.getElementById("StoreNameEdit").value.trim();

  if (!fullName || !storeName) {
    alert("⚠️ Please fill all editable fields.");
    return;
  }

  const user = firebase.auth().currentUser;
  if (!user) {
    alert("⛔ Not logged in.");
    return;
  }

  db.collection("users").doc(user.uid).update({
    fullName: fullName,
    storeName: storeName,
    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
  })
  .then(() => {
    alert("✅ Profile updated successfully!");
    setTimeout(() => location.reload(), 800);
  })
  .catch(error => {
    console.error("Error updating document: ", error);
    alert("❌ Failed to update profile.");
  });
});

//---------------------------------------------------------------------------Add pic

  function editPic() {
    const customUpload = document.getElementById("customUploadButton");

    customUpload.classList.remove("hide");
    customUpload.classList.add("show");
  }

  function editPic() {
    const customUpload = document.getElementById("customUploadButton");
    customUpload.classList.remove("hide");
    customUpload.classList.add("show");
  }

  document.getElementById("profilePicInput").addEventListener("change", function () {
    const customUpload = document.getElementById("customUploadButton");
    customUpload.classList.remove("show");
    customUpload.classList.add("hide");
  });


//--------------------------------------------------------------------- ✅ firebase-config.js

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCC6nznTDCkS-U7-CNkIWJJbrOMbnZ-HNU",
  authDomain: "notak-web.firebaseapp.com",
  projectId: "notak-web",
  storageBucket: "notak-web.appspot.com", // Fixed typo
  messagingSenderId: "355865509517",
  appId: "1:355865509517:web:2a69b2e9f4e9a51b056cc4",
  measurementId: "G-BLDYFE5VM4"
};

//--------------------------------------------------------------------- Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
const provider = new firebase.auth.GoogleAuthProvider();

//------------------------------------------------------------------------ Signup function

window.signUp = function () {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) return alert("📩 Enter email and password.");

  auth.createUserWithEmailAndPassword(email, password)
    .then(() => {
      alert("✅ Sign up successful!");
      window.location.href = "home.html";
    })
    .catch(error => alert("❌ " + error.message));
};
//------------------------------------------------------------------------ login function

window.login = function () {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) return alert("📩 Enter email and password.");

  auth.signInWithEmailAndPassword(email, password)
    .then(() => {
      alert("✅ Login successful!");
      window.location.href = "home.html";
    })
    .catch(error => alert("❌ " + error.message));
};
//------------------------------------------------------------------ SignIn with google function
window.signInWithGoogle = function () {
  auth.signInWithPopup(provider)
    .then(result => {
      alert("✅ Welcome, " + result.user.displayName);
      window.location.href = "home.html";
    })
    .catch(error => alert("❌ Google Sign-In failed: " + error.message));
};
//---------------------------------------------------------------------------- logout function
window.logout = function () {
  auth.signOut()
    .then(() => {
      alert("👋 Logged out!");
      window.location.href = "login.html";
    })
    .catch(error => alert("❌ Logout error: " + error.message));
};
//---------------------------------------------------------------------------Check auth function
window.checkAuth = function () {
  auth.onAuthStateChanged(user => {
    if (!user) {
      alert("⛔ Not logged in. Redirecting...");
      window.location.href = "login.html";
    } else {
      const userModal = document.getElementById("user-modal");
      const appContent = document.getElementById("app-content");

      db.collection("users").doc(user.uid).get()
        .then(doc => {
          if (doc.exists) {
            const userData = doc.data();
            localStorage.setItem("username", userData.userName);
            if (userModal) userModal.style.display = "none";
            if (appContent) appContent.style.display = "block";
          } else {
            if (userModal) userModal.style.display = "block";

            document.getElementById("saveUserInfoBtn").onclick = () => {
              const fullName = document.getElementById("fullName").value.trim();
              const userName = document.getElementById("userName").value.trim().toLowerCase();
              const storeName = document.getElementById("storeName").value.trim();

              if (!fullName || !userName || !storeName) {
                alert("❗ Please fill all fields.");
                return;
              }

              // Ensure unique username
              db.collection("users").where("userName", "==", userName).get()
                .then(snapshot => {
                  if (!snapshot.empty) {
                    alert("🚫 Username already taken.");
                    return;
                  }

                  db.collection("users").doc(user.uid).set({
                    fullName,
                    userName,
                    storeName,
                    email: user.email,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                  })
                  .then(() => {
                    alert("✅ Info saved!");
                    localStorage.setItem("username", userName);
                    if (userModal) userModal.style.display = "none";
                    if (appContent) appContent.style.display = "block";
                  })
                  .catch(error => alert("❌ Failed to save: " + error.message));
                });
            };
          }
        });
    }
  });
};

//------------------------------------------------------------------------Delete account function
window.deleteAccount = function () {
  const user = auth.currentUser;

  if (!user) return alert("⚠️ No user is logged in.");

  const confirmDelete = confirm("⚠️ Are you sure you want to delete your account and all your data? This cannot be undone.");

  if (!confirmDelete) return;

  // Ask for password if signed in with email/password
  const providerData = user.providerData[0]?.providerId;

  if (providerData === "password") {
    const password = prompt("🔐 Please re-enter your password to confirm account deletion:");
    const credential = firebase.auth.EmailAuthProvider.credential(user.email, password);

    user.reauthenticateWithCredential(credential)
      .then(() => proceedWithDeletion(user))
      .catch(error => alert("❌ Re-authentication failed: " + error.message));
  } else {
    // For Google Sign-In, re-auth with popup
    user.reauthenticateWithPopup(provider)
      .then(() => proceedWithDeletion(user))
      .catch(error => alert("❌ Re-authentication failed: " + error.message));
  }
};

// 🧹 Helper function to delete user data + account
function proceedWithDeletion(user) {
  db.collection("users").doc(user.uid).delete()
    .then(() => user.delete())
    .then(() => {
      alert("🗑️ Your account and data were deleted successfully.");
      window.location.href = "login.html";
    })
    .catch(error => alert("❌ Error deleting account: " + error.message));
}

// 📌 Listen for authentication state changes
firebase.auth().onAuthStateChanged(user => {

  // 🔒 Redirect to login if user is not authenticated
  if (!user) {
    alert("⛔ You are not logged in!");
    return window.location.href = "login.html";
  }

  // ✅ Get user-specific references from Firestore-------------------------------------------------
  const uid = user.uid;
  const userDocRef = db.collection("users").doc(uid); // reference to the user's document
  const categoryRef = userDocRef.collection("Category List"); // subcollection for categories

  // 🔧 UI Element references
  const categoryInput = document.getElementById("getCategory");
  const addButton = document.getElementById("newCategory");
  const categoryArea = document.getElementById("categoryArea");
  let deleteMode = false; // toggle for delete mode

  // 1️⃣ Live Store Name Display---------------------------------------------------------------->
  userDocRef.onSnapshot(doc => {
    if (doc.exists) {
      // Display the store name from Firestore in the UI
      document.getElementById("storeName").innerText = `${doc.data().storeName}`;
    } else {
      alert("❌ No user data found.");
    }
  }, error => {
    console.error("Error retrieving user data:", error);
    alert("❌ Error fetching user info.");
  });

  // 2️⃣ Function to Add New Category--------------------------------------------------------->
function makeNewCategory() {
  const categoryName = categoryInput.value.trim(); // get input value
  if (!categoryName) return;
  
  // Check for duplicate category names
  categoryRef
    .where("name", "==", categoryName)
    .get()
    .then(snapshot => {
      if (!snapshot.empty) {
        // Category with the same name already exists
        alert(`⚠️ The category "${categoryName}" already exists. Please use a different name.`);
        return;
      }
      
      // Add new category if it doesn't exist
      categoryRef.add({
          name: categoryName,
          icon: "/icons/m12.png", // default icon
          timestamp: firebase.firestore.FieldValue.serverTimestamp() // for ordering
        })
        .then(() => {
          categoryInput.value = ""; // clear input field
          bufferCategory = ""; // clear temporary buffer (assumed global)
          console.log("✅ Category added successfully!");
        })
        .catch(error => {
          console.error("Error adding category:", error);
          alert("❌ Failed to add category.");
        });
    })
    .catch(error => {
      console.error("Error checking for duplicate category:", error);
      alert("❌ An error occurred while checking for duplicate categories.");
    });
}


  // 3️⃣ Render Categories in Real-Time ---------------------------------------------------------->
  function renderCategories() {
    categoryRef.orderBy("timestamp", "desc").onSnapshot(snapshot => {
      categoryArea.innerHTML = ""; // clear existing categories

      snapshot.forEach(doc => {
        const data = doc.data();
        const id = doc.id;

        const p = document.createElement("p");
        p.innerText = data.name;
        p.id = id;
        p.className = "category-item";

        // 👉 Category click behavior
        p.addEventListener("click", () => {
          if (deleteMode) {
            if (confirm(`Delete category "${data.name}"?`)) {
              categoryRef.doc(id).delete().catch(err => console.error("❌ Delete error:", err));
            }
            deleteMode = false;
            categoryArea.classList.remove("delete-mode");
          } else {
            categoryInput.value = data.name; // fill input with category name
          }
        });

        categoryArea.appendChild(p); // add to DOM
      });
    });
  }

  renderCategories(); // initial render

  // 4️⃣ Toggle Delete Mode for Category Items-------------------------------------------------->
  window.deleteCategory = function () {
    deleteMode = true;
    categoryArea.classList.add("delete-mode");
  };

  // 5️⃣ Add Hover Styles for Delete Mode----------------------------------------------------->
  const style = document.createElement("style");
  style.innerHTML = `
    .delete-mode .category-item:hover {
      color: red;
      background-color: white;
      cursor: pointer;
    }
  `;
   document.head.appendChild(style); // inject CSS
  
  
  // 6️⃣ Event Listeners for Adding Category----------------------------------------------------->
  addButton.addEventListener("click", makeNewCategory);
  categoryInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault();
      makeNewCategory();
    }
  });

  // 7️⃣ Handle Transactions (income/expense)------------------------------------------------------>
  // Modified handleTransaction function
function handleTransaction(type) {
  const amount = document.getElementById("finalAmount").innerText.trim();
  const categoryName = document.getElementById("getCategory").value.trim();
  const fromDateInput = document.getElementById("fromDate").value;
  const toDateInput = document.getElementById("toDate").value;
  
  // Check if customDateContainer is displayed
  const customDateContainer = document.getElementById("customDateContainer");
  let specifiedDate;
  
  if (!customDateContainer || customDateContainer.style.display === "none") {
    // Use the current date if customDateContainer is not displayed
    specifiedDate = new Date();
  } else {
    // Validate and use the provided date
    if (!fromDateInput || !toDateInput) {
      alert("⚠️ Please specify both From Date and To Date.");
      return;
    }
    
    if (fromDateInput !== toDateInput) {
      alert("⚠️ From Date and To Date must be the same to add a transaction.");
      return;
    }
    
    specifiedDate = new Date(fromDateInput);
  }
  
  if (!amount || !categoryName) {
    alert("⚠️ Please enter both amount and category.");
    return;
  }
  
  let categoryIcon = "/icons/m5.png"; // default icon
  
  // Find matching category to get the icon
  categoryRef
    .where("name", "==", categoryName)
    .get()
    .then((snapshot) => {
      if (!snapshot.empty) {
        const docData = snapshot.docs[0].data();
        if (docData.icon) categoryIcon = docData.icon;
      }
      
      // Add to transition history with the specified date
      const transitionRef = userDocRef.collection("transition history");
      return transitionRef.add({
        category: categoryName,
        type: type,
        amount: amount,
        date: specifiedDate.toLocaleString(), // Use the specified date
        icon: categoryIcon,
        timestamp: firebase.firestore.Timestamp.fromDate(specifiedDate), // Use the specified date as timestamp
      });
    })
    .then(() => {
      // Reset form and buffer
      document.getElementById("amount").value = "";
      document.getElementById("finalAmount").innerText = "";
      bufferAmount = "";
      console.log("✅ Transaction saved!");
    })
    .catch((error) => {
      console.error("❌ Error saving transaction:", error);
      alert("Failed to save transaction.");
    });
}

  // 8️⃣ Render Transactions with Grouped Dates------------------------------------------------->
function renderTransitions() {
  const transitionMenu = document.getElementById("transitionMenu");
  const transitionRef = userDocRef.collection("transition history");
  
  transitionRef.orderBy("timestamp", "desc").onSnapshot(snapshot => {
    transitionMenu.innerHTML = ""; // clear previous content
    
    let transactionsByDate = {}; // Object to group transactions by date
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    
    function isSameDay(date1, date2) {
      return date1.getDate() === date2.getDate() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getFullYear() === date2.getFullYear();
    }
    
    snapshot.forEach(doc => {
      const data = doc.data();
      const originalDate = new Date(data.date);
      
      const dateLabel = formatDateLabel(originalDate);
      if (!transactionsByDate[dateLabel]) {
        transactionsByDate[dateLabel] = { income: 0, expense: 0, transactions: [] };
      }
      
      if (!isNaN(parseFloat(data.amount))) {
        if (data.type === "income") {
          transactionsByDate[dateLabel].income += parseFloat(data.amount);
        } else {
          transactionsByDate[dateLabel].expense += parseFloat(data.amount);
        }
      }
      
      transactionsByDate[dateLabel].transactions.push({ docId: doc.id, ...data });
    });
    
    for (const [dateLabel, { income, expense, transactions }] of Object.entries(transactionsByDate)) {
      const netAmount = income - expense; // Calculate net balance
      const netColor = netAmount >= 0 ? "rgba(69, 133, 86)" : "#e31f14"; // Green for positive, red for negative
      
  // Add date separator with net balance
const dateSeparator = document.createElement("div");
dateSeparator.className = "dateSeparator";
dateSeparator.innerHTML = `
  <span style="width: 16%">${dateLabel}</span>
  <span style="color: ${netColor}; font-weight: bold; font-family: var(--font16)">
    ₹${netAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
  </span>
`;
dateSeparator.style.cssText = `
  display: flex;
  width: 95.6%;
  flex-direction: row;
  font-weight: bold;
  border-top: 2px solid rgba(0, 0, 0, 0.3);
  margin-top: 13px; /* Reduced spacing */
  margin-bottom: 2px; /* Reduced spacing */
  padding-top: 4px;
  font-size: 16px;
  color: rgba(0,0,0,0.6);
  font-family: var(--font7); 
  position: sticky;
`;
transitionMenu.appendChild(dateSeparator);
      
      // Render transactions for the date
      transactions.forEach(data => {
        const transitionDescription = document.createElement("div");
        transitionDescription.className = "transitionDescription";
        
        const icon = document.createElement("img");
        icon.src = data.icon;
        icon.className = "transitionIcon";
        
        const category = document.createElement("p");
        category.innerText = data.category;
        category.className = "transitionCategory";
        
        const amount = document.createElement("p");
        amount.innerText = `₹${parseFloat(data.amount).toLocaleString()}`;
        amount.className = "transitionAmount";
        amount.style.color = data.type === "income" ? "rgba(69, 133, 86)" : "#e31f14";
        
        const date = document.createElement("p");
        date.innerText = dateLabel;
        date.className = "transitionDate";
        
        transitionDescription.style.borderLeft = data.type === "income" ?
          "3px solid #7ba368" :
          "3px solid #eb4a42";
        
        transitionDescription.append(icon, category, date, amount);
        transitionMenu.appendChild(transitionDescription);
        
        // ➕ Add long-press delete behavior
        let pressTimer;
        let isHolding = false;
        
        const handleDelete = () => {
          userDocRef.collection("transition history").doc(data.docId).delete();
          transitionDescription.remove();
        };
        
        transitionDescription.addEventListener("mousedown", () => {
          pressTimer = setTimeout(() => {
            isHolding = true;
            transitionDescription.style.transition = "background-color 0.5s";
            transitionDescription.style.backgroundColor = "#ed533b";
          }, 1200);
        });
        
        transitionDescription.addEventListener("mouseup", () => {
          clearTimeout(pressTimer);
          if (isHolding) handleDelete();
          isHolding = false;
          transitionDescription.style.backgroundColor = "";
        });
        
        transitionDescription.addEventListener("mouseleave", () => {
          clearTimeout(pressTimer);
          isHolding = false;
          transitionDescription.style.backgroundColor = "";
        });
      });
    }
    
    if (!transitionMenu.hasChildNodes()) {
      transitionMenu.innerHTML = `<p style="text-align:center; margin-top:20px; color:gray;">No Transaction History Stored Yet</p>`;
    }
  });
}
  
// Format date label ------------------------------------------------------------------------>
function formatDateLabel(dateObj) {
  const day = String(dateObj.getDate()).padStart(2, "0");
  const month = dateObj.toLocaleString('default', { month: 'short' });
  const year = dateObj.getFullYear();
  return `${day} ${month} ${year}`;
}
  renderTransitions(); // render on load
  renderWalletBalance(); // show wallet balance

  // 📊 Chart Toggle Buttons----------------------------------------------------------------->
  document.getElementById("dailyBtn").addEventListener("click", () => {
    renderIncomeExpenseChart("daily");
  });

  document.getElementById("weeklyBtn").addEventListener("click", () => {
    renderIncomeExpenseChart("weekly");
  });

  document.getElementById("monthlyBtn").addEventListener("click", () => {
    renderIncomeExpenseChart("monthly");
  });

  // 9️⃣ Real-time Wallet Balance Display-------------------------------------------------------->
  function renderWalletBalance() {
    const walletText = document.getElementById("wallet");
    const transitionRef = userDocRef.collection("transition history");

    transitionRef.onSnapshot(snapshot => {
      let total = 0;

      snapshot.forEach(doc => {
        const data = doc.data();
        const amount = parseFloat(data.amount);
        if (!isNaN(amount)) {
          total += data.type === "income" ? amount : -amount;
        }
      });

      const absTotal = Math.abs(total).toLocaleString(undefined, { minimumFractionDigits: 2 });
      const symbol = total < 0 ? "-" : "";
      const color = total < 0 ? "#e82a15" : "#52854e";

      walletText.innerHTML = `Wallet: <span style="color: ${color}">${symbol} ₹${absTotal}</span>`;
    });
  }

  // 🔄 Pie Chart: Income vs Expense---------------------------------------------------------->
  function renderIncomeExpenseChart(range = 'daily') {
    const ctx = document.getElementById("transitionChart").getContext("2d");
    const transitionRef = userDocRef.collection("transition history");

    const now = new Date();
    let startDate, endDate;

    if (range === 'daily') {
      startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    } else if (range === 'weekly') {
      const dayOfWeek = now.getDay();
      startDate = new Date(now);
      startDate.setDate(now.getDate() - dayOfWeek);
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date(startDate);
      endDate.setDate(startDate.getDate() + 7);
    } else if (range === 'monthly') {
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      endDate = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    }

    transitionRef
      .where("timestamp", ">=", firebase.firestore.Timestamp.fromDate(startDate))
      .where("timestamp", "<", firebase.firestore.Timestamp.fromDate(endDate))
      .onSnapshot(snapshot => {
      let totalIncome = 0;
      let totalExpense = 0;
      
      if (snapshot.empty) {
        if (window.pieChartInstance) {
          window.pieChartInstance.destroy();
          window.pieChartInstance = null;
        }
        
        const netAmountDiv = document.getElementById("netAmount");
        if (netAmountDiv) {
          netAmountDiv.innerText = `Net Balance: ₹0.00`;
        }
        
        return; // 🔁 Exit early, no data to show
      }
      
      snapshot.forEach(doc => {
        const data = doc.data();
        const amount = parseFloat(data.amount);
        const type = data.type;
        
        if (!isNaN(amount)) {
          if (type === "income") totalIncome += amount;
          else if (type === "expense") totalExpense += amount;
        }
      });

        const net = totalIncome - totalExpense;

        const chartData = {
          labels: [
            `Income: ₹${totalIncome.toLocaleString()}`,
            `Expense: ₹${totalExpense.toLocaleString()}`
          ],
          datasets: [{
            data: [totalIncome, totalExpense],
            backgroundColor: ['#789c81', '#ed533b'],
            borderColor: ['rgba(0, 0, 0, 0.9)', 'rgba(0, 0, 0, 0.5)'],
            borderWidth: 1
          }]
        };

        if (window.pieChartInstance) {
          window.pieChartInstance.destroy();
        }

        window.pieChartInstance = new Chart(ctx, {
          type: 'doughnut',
          data: chartData,
          options: {
            responsive: true,
            cutout: '60%',
            plugins: {
              legend: {
                display: true,
                position: 'bottom',
                align: 'center',
                labels: {
                  boxWidth: 20,
                  padding: 6,
                  color: '#333',
                  font: {
                    size: 14,
                    weight: 'bold'
                  }
                }
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    const value = context.raw;
                    return `₹${value.toLocaleString()}`;
                  }
                }
              }
            }
          }
        });

        const netAmountDiv = document.getElementById("netAmount");
        if (netAmountDiv) {
          netAmountDiv.innerText = `Net Balance: ₹${net.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
        }

      }, error => {
        console.error("Chart rendering error:", error);
      });
  }

  renderIncomeExpenseChart('daily'); // default chart range
  
  
// Custom Date Feature-------------------------------------------------------------------------->

const customDateBtn = document.getElementById("customDateBtn");
const customDateContainer = document.getElementById("customDateContainer");
const fromDateInput = document.getElementById("fromDate");
const toDateInput = document.getElementById("toDate");

// Toggle date input container visibility
customDateBtn.addEventListener("click", () => {
  // Check current display style of the container
  const isVisible = customDateContainer.style.display === "flex";
  
  // Toggle visibility
  if (isVisible) {
    customDateContainer.style.display = "none"; // Hide container
    renderTransitions(); // Render all transaction history
    renderIncomeExpenseChart("daily"); // Render pie chart for the current date
  } else {
    customDateContainer.style.display = "flex"; // Show container
    setDefaultDates(); // Set default dates when the container is visible
  }
});

// Set default date values for fromDate and toDate
function setDefaultDates() {
  const todayStr = new Date().toISOString().split("T")[0]; // Get today's date in YYYY-MM-DD format
  fromDateInput.value = todayStr; // Set default value for 'fromDate'
  toDateInput.value = todayStr; // Set default value for 'toDate'
}

// Hook inputs to listen for changes and re-render data
[fromDateInput, toDateInput].forEach(input => {
  input.addEventListener("change", () => {
    renderCustomDateHistory(); // Render transactions based on selected date range
    renderCustomPieChart(); // Render pie chart based on selected date range
  });
});

// Render transaction history based on custom date-------------------------------------------->
function renderCustomDateHistory() {
  const fromVal = fromDateInput.value;
  const toVal = toDateInput.value || fromVal; // Use 'fromDate' if 'toDate' is not set
  
  if (!fromVal) return; // Exit early if no date is selected
  
  const transitionMenu = document.getElementById("transitionMenu");
  const transitionRef = userDocRef.collection("transition history");
  
  const fromDate = new Date(fromVal);
  const toDate = new Date(toVal);
  
  // Set 'toDate' to end of the day
  toDate.setHours(23, 59, 59, 999);
  
  // Object to group transactions by date
  const transactionsByDate = {};
  
  // Firestore query for the custom date range
  transitionRef
    .where("timestamp", ">=", firebase.firestore.Timestamp.fromDate(fromDate))
    .where("timestamp", "<=", firebase.firestore.Timestamp.fromDate(toDate))
    .orderBy("timestamp", "desc")
    .onSnapshot(snapshot => {
      transitionMenu.innerHTML = ""; // Clear previous content
      
      snapshot.forEach(doc => {
        const data = doc.data();
        const timestampDate = data.timestamp?.toDate?.(); // Firestore timestamp to JS Date object
        
        // Skip transactions outside the custom date range
        if (!timestampDate || timestampDate < fromDate || timestampDate > toDate) return;
        
        const formattedDate = formatDateLabel(timestampDate);
        
        // Initialize income, expense, and transactions for the date
        if (!transactionsByDate[formattedDate]) {
          transactionsByDate[formattedDate] = { income: 0, expense: 0, transactions: [] };
        }
        
        // Add transaction to the date group
        transactionsByDate[formattedDate].transactions.push({ docId: doc.id, ...data });
        
        // Calculate income/expense
        const amount = parseFloat(data.amount);
        if (!isNaN(amount)) {
          if (data.type === "income") {
            transactionsByDate[formattedDate].income += amount;
          } else if (data.type === "expense") {
            transactionsByDate[formattedDate].expense += amount;
          }
        }
      });
      
      // Render grouped transactions by date
      for (const [dateLabel, { income, expense, transactions }] of Object.entries(transactionsByDate)) {
        const netAmount = income - expense; // Calculate net balance
        const netColor = netAmount >= 0 ? "rgba(69, 133, 86)" : "#e31f14"; // Green for positive, red for negative
        
        // Add date separator with net balance
        const dateSeparator = document.createElement("div");
        dateSeparator.className = "dateSeparator";
        dateSeparator.innerHTML = `
          <span style="width: 16%">${dateLabel}</span>
          <span style="color: ${netColor}; font-weight: bold; font-family: var(--font16)">
            ₹${netAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
        `;
        dateSeparator.style.cssText = `
          display: flex;
          width: 95.6%;
          flex-direction: row;
          font-weight: bold;
          border-top: 2px solid rgba(0, 0, 0, 0.3);
          margin-top: 13px; /* Reduced spacing */
          margin-bottom: 2px; /* Reduced spacing */
          padding-top: 4px;
          font-size: 16px;
          color: rgba(0,0,0,0.6);
          font-family: var(--font7); 
          position: sticky;
        `;
        transitionMenu.appendChild(dateSeparator);
        
        // Render transactions for the date
        transactions.forEach(data => {
          const transitionDescription = document.createElement("div");
          transitionDescription.className = "transitionDescription";
          
          const icon = document.createElement("img");
          icon.src = data.icon;
          icon.className = "transitionIcon";
          
          const category = document.createElement("p");
          category.innerText = data.category;
          category.className = "transitionCategory";
          
          const amount = document.createElement("p");
          amount.innerText = `₹${parseFloat(data.amount).toLocaleString()}`;
          amount.className = "transitionAmount";
          amount.style.color = data.type === "income" ? "rgba(69, 133, 86)" : "#e31f14";
          
          const date = document.createElement("p");
          date.innerText = dateLabel;
          date.className = "transitionDate";
          
          transitionDescription.style.borderLeft = data.type === "income" ?
            "3px solid #7ba368" :
            "3px solid #eb4a42";
          
          transitionDescription.append(icon, category, date, amount);
          transitionMenu.appendChild(transitionDescription);
          
          // Add long-press delete behavior
          let timer;
          let isHolding = false;
          
          transitionDescription.addEventListener("mousedown", () => {
            timer = setTimeout(() => {
              isHolding = true;
              transitionDescription.style.backgroundColor = "#ed533b";
              userDocRef.collection("transition history").doc(data.docId).delete();
            }, 1200);
          });
          
          transitionDescription.addEventListener("mouseup", () => {
            clearTimeout(timer);
            isHolding = false;
            transitionDescription.style.backgroundColor = "";
          });
          
          transitionDescription.addEventListener("mouseleave", () => {
            clearTimeout(timer);
            isHolding = false;
            transitionDescription.style.backgroundColor = "";
          });
        });
      }
      
      if (!transitionMenu.hasChildNodes()) {
        transitionMenu.innerHTML = `<p style="text-align:center; margin-top:20px; color:gray;">No Transaction History Stored Yet</p>`;
      }
    });
}

// Render a custom pie chart based on the selected date range-------------------------------->
function renderCustomPieChart() {
  const fromVal = fromDateInput.value;
  const toVal = toDateInput.value || fromVal;
  
  if (!fromVal) return renderIncomeExpenseChart("daily"); // Default to daily chart if no custom date is selected
  
  const fromDate = new Date(fromVal);
  fromDate.setHours(0, 0, 0, 0);
  
  const toDate = new Date(toVal);
  toDate.setHours(23, 59, 59, 999);
  
  const ctx = document.getElementById("transitionChart").getContext("2d");
  const transitionRef = userDocRef.collection("transition history");
  
  if (unsubscribePieChart) {
    unsubscribePieChart();
  }
  
  unsubscribePieChart = transitionRef
    .where("timestamp", ">=", firebase.firestore.Timestamp.fromDate(fromDate))
    .where("timestamp", "<=", firebase.firestore.Timestamp.fromDate(toDate))
    .onSnapshot(snapshot => {
      let totalIncome = 0;
      let totalExpense = 0;
      
      snapshot.forEach(doc => {
        const data = doc.data();
        const amount = parseFloat(data.amount);
        const type = data.type;
        
        if (!isNaN(amount)) {
          if (type === "income") totalIncome += amount;
          else if (type === "expense") totalExpense += amount;
        }
      });
      
      const net = totalIncome - totalExpense;
      
      const chartData = {
        labels: [
          `Income: ₹${totalIncome.toLocaleString()}`,
          `Expense: ₹${totalExpense.toLocaleString()}`
        ],
        datasets: [{
          data: [totalIncome, totalExpense],
          backgroundColor: ['#789c81', '#ed533b'],
          borderColor: ['rgba(0, 0, 0, 0.9)', 'rgba(0, 0, 0, 0.5)'],
          borderWidth: 1
        }]
      };
      
      if (window.pieChartInstance) {
        window.pieChartInstance.destroy();
      }
      
      window.pieChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: {
          responsive: true,
          cutout: '60%',
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
              align: 'center',
              labels: {
                boxWidth: 20,
                padding: 6,
                color: '#333',
                font: {
                  size: 14,
                  weight: 'bold'
                }
              }
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const value = context.raw;
                  return `₹${value.toLocaleString()}`;
                }
              }
            }
          }
        }
      });
      
      const netAmountDiv = document.getElementById("netAmount");
      if (netAmountDiv) {
        netAmountDiv.innerText = `Net Balance: ₹${net.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
      }
    });
}

let unsubscribePieChart = null;


//----------------------------------------------------------------------------------------------->
function renderCustomPieChart() {
  const fromVal = fromDateInput.value;
  const toVal = toDateInput.value || fromVal;

  if (!fromVal) return renderIncomeExpenseChart("daily");

  // Set start of day for fromDate
  const fromDate = new Date(fromVal);
  fromDate.setHours(0, 0, 0, 0);

  // Set end of day for toDate
  const toDate = new Date(toVal);
  toDate.setHours(23, 59, 59, 999);

  const ctx = document.getElementById("transitionChart").getContext("2d");
  const transitionRef = userDocRef.collection("transition history");

  // Unsubscribe from the previous snapshot listener if it exists
  if (unsubscribePieChart) {
    unsubscribePieChart();
  }

  unsubscribePieChart = transitionRef
    .where("timestamp", ">=", firebase.firestore.Timestamp.fromDate(fromDate))
    .where("timestamp", "<=", firebase.firestore.Timestamp.fromDate(toDate))
    .onSnapshot(snapshot => {
      let totalIncome = 0;
      let totalExpense = 0;

      snapshot.forEach(doc => {
        const data = doc.data();
        const amount = parseFloat(data.amount);
        const type = data.type;

        if (!isNaN(amount)) {
          if (type === "income") totalIncome += amount;
          else if (type === "expense") totalExpense += amount;
        }
      });

      const net = totalIncome - totalExpense;

      const chartData = {
        labels: [
          `Income: ₹${totalIncome.toLocaleString()}`,
          `Expense: ₹${totalExpense.toLocaleString()}`
        ],
        datasets: [{
          data: [totalIncome, totalExpense],
          backgroundColor: ['#789c81', '#ed533b'],
          borderColor: ['rgba(0, 0, 0, 0.9)', 'rgba(0, 0, 0, 0.5)'],
          borderWidth: 1
        }]
      };

      // Destroy the previous pie chart instance if it exists
      if (window.pieChartInstance) {
        window.pieChartInstance.destroy();
      }

      // Create a new pie chart instance
      window.pieChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: {
          responsive: true,
          cutout: '60%',
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
              align: 'center',
              labels: {
                boxWidth: 20,
                padding: 6,
                color: '#333',
                font: {
                  size: 14,
                  weight: 'bold'
                }
              }
            },
            tooltip: {
              callbacks: {
                label: function (context) {
                  const value = context.raw;
                  return `₹${value.toLocaleString()}`;
                }
              }
            }
          }
        }
      });

      const netAmountDiv = document.getElementById("netAmount");
      if (netAmountDiv) {
        netAmountDiv.innerText = `Net Balance: ₹${net.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
      }
    });
}

  // 🔘 Expose Transaction Functions to Window--------------------------------------------------->
  window.getIncome = () => handleTransaction("income");
  window.getExpense = () => handleTransaction("expense");
});

// 🔄 Clear input fields on page reload---------------------------------------------------------->
window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("amount").value = "";
  document.getElementById("getCategory").value = "";
  document.getElementById("finalAmount").innerText = "";
  bufferAmount = "";
  bufferCategory = "";
});

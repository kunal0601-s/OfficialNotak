// ------------------------------------- First screen -------------------------------------------

// Typewriter Animation
const text = "Chalo Profit ko Calculate Karen !";
const typewriterElement = document.querySelector('.typewriter');
let charIndex = 0;

function typeWriter() {
  if (charIndex < text.length) {
    typewriterElement.textContent += text.charAt(charIndex);
    charIndex++;
    setTimeout(typeWriter, 100);
  } else {
    // Show welcome box after typing animation
    setTimeout(() => {
      document.querySelector('.welcome-box').classList.add('show');
    }, 500);
  }
}

// Start typewriter animation after fade-in
setTimeout(typeWriter, 3000);

// Switch to home page from welcome screen
function welcomeBtn() {
  document.querySelector('.web-anime').style.display = 'none';
  window.location.href = 'home.html';
}


// -------------------------------- Signup/Login Button Navigation --------------------------------

function openLogin() {
  window.location.href = 'login.html';
}

function openSignup() {
  window.location.href = 'signup.html';
}


// --------------------------------- Google Icon Animation ---------------------------------

const icon = document.getElementById("google-icon");

if (icon) {
  document.addEventListener("mousemove", (event) => {
    const iconRect = icon.getBoundingClientRect();
    const iconCenterX = iconRect.left + iconRect.width / 2;
    const iconCenterY = iconRect.top + iconRect.height / 2;

    const deltaX = event.clientX - iconCenterX;
    const deltaY = event.clientY - iconCenterY;
    const distance = Math.sqrt(deltaX ** 2 + deltaY ** 2);

    if (distance < 30) {
      const moveX = (deltaX / distance) * 10;
      const moveY = (deltaY / distance) * 10;
      icon.style.transform = `translate(${moveX}px, ${moveY}px)`;
    } else {
      icon.style.transform = "translate(0, 0)";
    }
  });
}


// --------------------------------- Navigation Buttons ---------------------------------

function openMain() {
  document.getElementById("main-container").style.display = "none";
  const frame = document.getElementById("containerFrame");
  frame.style.display = "block";
  frame.src = "page-main.html";
}

function openOrders() {
  document.getElementById("main-container").style.display = "none";
  const frame = document.getElementById("containerFrame");
  frame.style.display = "block";
  frame.src = "page-orders.html";
}

function openCategories() {
  document.getElementById("main-container").style.display = "none";
  const frame = document.getElementById("containerFrame");
  frame.style.display = "block";
  frame.src = "page-categories.html";
}

function openAnalysis() {
  document.getElementById("main-container").style.display = "none";
  const frame = document.getElementById("containerFrame");
  frame.style.display = "block";
  frame.src = "page-analysis.html";
}

function openProfile() {
  document.getElementById("main-container").style.display = "none";
  const frame = document.getElementById("containerFrame");
  frame.style.display = "block";
  frame.src = "page-profile.html";
}

function openNotes() {
  document.getElementById("main-container").style.display = "none";
  const frame = document.getElementById("containerFrame");
  frame.style.display = "block";
  frame.src = "page-notes.html";
}

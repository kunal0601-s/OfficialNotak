// 📌 Listen for authentication state changes
firebase.auth().onAuthStateChanged(user => {
      // 🔒 Redirect to login if user is not authenticated
      if (!user) {
        alert("⛔ You are not logged in!");
        return window.location.href = "login.html";
      }
      
      // ✅ Get user-specific references from Firestore
      const uid = user.uid;
      const userDocRef = db.collection("users").doc(uid); // reference to the user's document
      const categoryRef = userDocRef.collection("Category List"); // subcollection for categories
      const transactionRef = userDocRef.collection("transition history"); // reference to transactions
      
      // 🔧 UI Element references
      const categoryInput = document.getElementById("getCategory");
      const addButton = document.getElementById("newCategory");
      const categoryArea = document.getElementById("categoryArea");
      const transactionMenu = document.getElementById("transitionMenu");
      const customDateBtn = document.getElementById("customDateBtn");
      const customDateContainer = document.getElementById("customDateContainer");
      const fromDateInput = document.getElementById("fromDate");
      const toDateInput = document.getElementById("toDate");
      
      // 🔧 New UI Elements
      const altSaveIcon = document.getElementById("altSaveIcon");
      const iconMenu = document.getElementById("iconMenu");
      const getCatInput = document.getElementById("getCatInput");
      const categoriesAnim = document.getElementById("CategoriesAnim");
      const changeIcon = document.getElementById("changeIcon");
      
      // 🔧 New UI Elements for Swap Category Feature
      const swapCategoryBtn = document.getElementById("swapCategory"); // Button to toggle swap feature
      const swapIcon = document.getElementById("swap"); // Swap image
      const changeCategoryInput = document.getElementById("changeCategory"); // Input for new category name
      const saveSwapBtn = document.getElementById("saveSwap"); // Button to save the swapped category name
      
      // Initial visibility of swap elements (hidden by default)
      swapIcon.style.display = "none";
      changeCategoryInput.style.display = "none";
      saveSwapBtn.style.display = "none";
      
      let deleteMode = false; // toggle for delete mode
      let eventListenersRegistered = false;
      let selectedIconFilename = null; // store the selected icon filename

  // 1️⃣ Live Store Name Display
  userDocRef.onSnapshot(
    doc => {
      if (doc.exists) {
        // Display the store name from Firestore in the UI
        document.getElementById("storeName").innerText = `${doc.data().storeName}`;
      } else {
        alert("❌ No user data found.");
      }
    },
    error => {
      console.error("Error retrieving user data:", error);
      alert("❌ Error fetching user info.");
    }
  );

   // 🔄 Toggle Visibility of Swap Elements
  swapCategoryBtn.addEventListener("click", () => {
    const isVisible = swapIcon.style.display === "block";
    
    if (isVisible) {
      // Hide swap elements
      swapIcon.style.display = "none";
      changeCategoryInput.style.display = "none";
      saveSwapBtn.style.display = "none";
    } else {
      // Show swap elements
      swapIcon.style.display = "block";
      changeCategoryInput.style.display = "block";
      saveSwapBtn.style.display = "block";
    }
  });
  
  // 💾 Save Swapped Category Name
saveSwapBtn.addEventListener("click", () => {
  const oldCategoryName = categoryInput.value.trim(); // Current category name
  const newCategoryName = changeCategoryInput.value.trim(); // New category name
  
  if (!oldCategoryName || !newCategoryName) {
    alert("⚠️ Both category names must be filled out.");
    return;
  }
  
  if (oldCategoryName === newCategoryName) {
    alert("⚠️ The new category name must be different from the current category name.");
    return;
  }
  
  // Check if the old category exists in Firestore
  categoryRef
    .where("name", "==", oldCategoryName)
    .get()
    .then(snapshot => {
      if (snapshot.empty) {
        alert(`⚠️ Category "${oldCategoryName}" does not exist.`);
        return;
      }
      
      // Update the category name in Firestore
      const batch = db.batch(); // Use a batch to ensure atomic updates
      snapshot.forEach(doc => {
        const categoryDocRef = categoryRef.doc(doc.id);
        batch.update(categoryDocRef, { name: newCategoryName });
      });
      
      // Update the category name in transaction history
      return transactionRef
        .where("category", "==", oldCategoryName)
        .get()
        .then(transSnapshot => {
          transSnapshot.forEach(doc => {
            const transactionDocRef = transactionRef.doc(doc.id);
            batch.update(transactionDocRef, { category: newCategoryName });
          });
          
          // Commit all updates
          return batch.commit();
        });
    })
    .then(() => {
      alert(`✅ Category name changed from "${oldCategoryName}" to "${newCategoryName}" successfully!`);
      categoryInput.value = ""; // Clear input field
      changeCategoryInput.value = ""; // Clear new category input field
      
      // Refresh the transactions in the UI
      renderTransitions();
    })
    .catch(error => {
      console.error("Error updating category name:", error);
      alert("❌ Failed to update category name.");
    });
});


 // 2️⃣ Function to Add New Category with Duplicate Check
 function makeNewCategory() {
   const categoryName = categoryInput.value.trim(); // get input value
   if (!categoryName) return;
   
   // Disable the Add button to prevent multiple clicks
   addButton.disabled = true;
   
   // Check if the category already exists
   categoryRef
     .where("name", "==", categoryName)
     .get()
     .then(snapshot => {
       if (!snapshot.empty) {
         // Category already exists
         alert(`⚠️ Category "${categoryName}" already exists!`);
         categoryInput.value = ""; // clear input field
         addButton.disabled = false; // Re-enable the Add button
         return;
       }
       
       // Add the new category to Firestore
       return categoryRef.add({
         name: categoryName,
         icon: "/icons/m12.png", // default icon (only filename stored)
         timestamp: firebase.firestore.FieldValue.serverTimestamp() // for ordering
       });
     })
     .then(() => {
       categoryInput.value = ""; // clear input field
       console.log(`✅ Category "${categoryName}" added successfully!`);
     })
     .catch(error => {
       console.error("Error adding category:", error);
       alert("❌ Failed to add category.");
     })
     .finally(() => {
       addButton.disabled = false; // Re-enable the Add button
     });
 }

  // 3️⃣ Handle Icon Selection
  iconMenu.addEventListener("click", event => {
    if (event.target.tagName === "IMG") {
      const fullIconSrc = event.target.src; // Full URL of the selected icon
      selectedIconFilename = "/icons/" + fullIconSrc.split("/").pop(); // Extract and store filename with "/icons/" prefix
      changeIcon.src = fullIconSrc; // Update changeIcon image
    }
  });
  

  // 4️⃣ Handle Save Action
  function handleSaveAction() {
    const categoryName = getCatInput.value.trim();

    if (!selectedIconFilename) {
      alert("⚠️ Please select an icon.");
      return;
    }
    if (!categoryName) {
      alert("⚠️ Please enter a category name.");
      return;
    }

    // Check if the category exists
    categoryRef
      .where("name", "==", categoryName)
      .get()
      .then(snapshot => {
        if (snapshot.empty) {
          alert(`⚠️ Category "${categoryName}" does not exist.`);
          return;
        }

        // Update the icon in Firestore
        snapshot.forEach(doc => {
          categoryRef.doc(doc.id).update({ icon: selectedIconFilename });
        });

        // Update the icon in transaction history
        transactionRef
          .where("category", "==", categoryName)
          .get()
          .then(snapshot => {
            snapshot.forEach(doc => {
              transactionRef.doc(doc.id).update({ icon: selectedIconFilename });
            });
          });

        alert(`✅ Icon for "${categoryName}" updated successfully!`);
      })
      .catch(error => {
        console.error("Error updating icon:", error);
        alert("❌ Failed to update icon.");
      });
  }

  // 🔄 Toggle Icon Menu and Reset to Default
  changeIcon.addEventListener("click", () => {
    const isIconMenuVisible = iconMenu.style.display === "block";

    if (isIconMenuVisible) {
      // Hide iconMenu and altSaveIcon, show categoriesAnim
      iconMenu.style.display = "none";
      altSaveIcon.style.display = "none";
      categoriesAnim.style.display = "block";

      // Reset changeIcon to its default image
      changeIcon.src = "/search.png"; // Replace with the path to your default image
      selectedIconFilename = null; // Clear selected icon source
    } else {
      // Show iconMenu and altSaveIcon, hide categoriesAnim
      iconMenu.style.display = "block";
      altSaveIcon.style.display = "block";
      categoriesAnim.style.display = "none";
    }
  });

  altSaveIcon.addEventListener("click", handleSaveAction);
  getCatInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSaveAction();
    }
  });

  renderCategories(); // initial render
  renderTransitions(); // initial render

 // 5️⃣ Render Categories in Real-Time
 function renderCategories() {
   categoryRef.orderBy("timestamp", "desc").onSnapshot(snapshot => {
     categoryArea.innerHTML = ""; // clear existing categories
     
     snapshot.forEach(doc => {
       const data = doc.data();
       const id = doc.id;
       
       const p = document.createElement("p");
       p.innerText = data.name;
       p.id = id;
       p.className = "category-item";
       
       // 👉 Category click behavior
       p.addEventListener("click", () => {
         if (deleteMode) {
           if (confirm(`Delete category "${data.name}"?`)) {
             categoryRef.doc(id).delete().catch(err => console.error("❌ Delete error:", err));
           }
           deleteMode = false;
           categoryArea.classList.remove("delete-mode");
         } else {
           getCatInput.value = data.name; // fill input with category name
         }
       });
       
       categoryArea.appendChild(p); // add to DOM
     });
   });
 }
 
 

  // 6️⃣ Toggle Delete Mode for Category Items
  window.deleteCategory = function () {
    deleteMode = true;
    categoryArea.classList.add("delete-mode");
  };

  // 7️⃣ Add Hover Styles for Delete Mode
  const style = document.createElement("style");
  style.innerHTML = `
    .delete-mode .category-item:hover {
      color: red;
      background-color: white;
      cursor: pointer;
    }
  `;
  document.head.appendChild(style); // inject CSS
  

  // 6️⃣ Event Listeners (Ensure they are added only once)
  if (!eventListenersRegistered) {
    addButton.addEventListener("click", makeNewCategory);
    categoryInput.addEventListener("keydown", e => {
      if (e.key === "Enter") {
        e.preventDefault();
        makeNewCategory();
      }
    });

    eventListenersRegistered = true; // Mark listeners as registered
  }

  // 7️⃣ Render Transactions with Blank Div Between Category and Amount
function renderTransitions(fromDate = null, toDate = null) {
  const transitionRef = userDocRef.collection("transition history");
  
  let query = transitionRef.orderBy("timestamp", "desc");
  if (fromDate && toDate) {
    const toDateEndOfDay = new Date(toDate);
    toDateEndOfDay.setHours(23, 59, 59, 999); // Set to the end of the day
    
    query = query.where(
      "timestamp",
      ">=",
      firebase.firestore.Timestamp.fromDate(new Date(fromDate))
    ).where(
      "timestamp",
      "<=",
      firebase.firestore.Timestamp.fromDate(toDateEndOfDay)
    );
  }
  
  query.onSnapshot(snapshot => {
    transactionMenu.innerHTML = ""; // Clear previous content
    
    if (snapshot.empty) {
      const noDataMessage = document.createElement("p");
      noDataMessage.className = "no-data-message";
      noDataMessage.innerText = "No Transaction History Found";
      noDataMessage.style.cssText = `
        text-align: center;
        margin-top: 20px;
        color: rgba(0,0,0,0.6);
        font-size: 16px;
        font-family: var(--font7);
      `;
      transactionMenu.appendChild(noDataMessage);
      return;
    }
    
    let lastRenderedDate = null;
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    
    const dateNetAmounts = {}; // Store net amounts per date
    
    function getDateKey(dateObj) {
      // Ensure consistent date key (ignoring time)
      const year = dateObj.getFullYear();
      const month = String(dateObj.getMonth() + 1).padStart(2, "0");
      const day = String(dateObj.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    }
    
    // First Pass: Calculate Net Amounts for Each Date
    snapshot.forEach(doc => {
      const data = doc.data();
      const originalDate = data.timestamp?.toDate();
      const dateKey = getDateKey(originalDate); // Use consistent date key
      
      // Initialize net amount for the date if not already present
      if (!dateNetAmounts[dateKey]) {
        dateNetAmounts[dateKey] = 0;
      }
      
      // Parse and update net amount based on transaction type
      const transactionAmount = parseFloat(data.amount) || 0; // Ensure amount is a number
      if (data.type === "income") {
        dateNetAmounts[dateKey] += transactionAmount;
      } else if (data.type === "expense") {
        dateNetAmounts[dateKey] -= transactionAmount;
      }
    });
    
    // Second Pass: Render Transactions and Date Separators
    snapshot.forEach(doc => {
      const data = doc.data();
      const originalDate = data.timestamp?.toDate();
      const dateKey = getDateKey(originalDate); // Use consistent date key
      
      let dateLabel = formatDateLabel(originalDate);
      if (isSameDay(originalDate, today)) dateLabel += " ( Today )";
      else if (isSameDay(originalDate, yesterday)) dateLabel += " ( Yesterday )";
      
      if (dateLabel !== lastRenderedDate) {
        lastRenderedDate = dateLabel;
        
        const netAmount = dateNetAmounts[dateKey]; // Get net amount for the date
        const netAmountColor = netAmount >= 0 ? "rgba(69, 133, 86)" : "#e31f14";
        
        const dateSeparator = document.createElement("div");
        dateSeparator.className = "dateSeparator";
        dateSeparator.innerHTML = `
          ${dateLabel} 
          <span style="color: ${netAmountColor}; font-weight: 700; font-size: 16px; font-family: var(--font16); margin-left: 7px;">
            ₹${netAmount.toLocaleString()}
          </span>
        `;
dateSeparator.style.cssText = `
  display: flex;
  width: 97.5%;
  flex-direction: row;
  font-weight: bold;
  border-top: 2px solid rgba(0, 0, 0, 0.3);
  margin-top: 13px; /* Reduced spacing */
  margin-bottom: 2px; /* Reduced spacing */
  padding-top: 4px;
  font-size: 16px;
  color: rgba(0,0,0,0.6);
  font-family: var(--font7); 
  position: sticky;
`;
        transactionMenu.appendChild(dateSeparator);
      }
      
      const transitionDescription = document.createElement("div");
      transitionDescription.className = "transitionDescription";
      
      const icon = document.createElement("img");
      icon.src = data.icon;
      icon.className = "transitionIcon";
      
      const category = document.createElement("p");
      category.innerText = data.category;
      category.className = "transitionCategory";
      
      const blankDiv = document.createElement("div");
      blankDiv.className = "transitionBlank";
      
      const amount = document.createElement("p");
      amount.innerText = `₹${parseFloat(data.amount).toLocaleString()}`;
      amount.className = "transitionAmount";
      amount.style.color = data.type === "income" ? "rgba(69, 133, 86)" : "#e31f14";
      
      transitionDescription.style.borderLeft = data.type === "income" ?
        "3px solid #7ba368" :
        "3px solid #eb4a42";
      
      transitionDescription.append(icon, category, blankDiv, amount);
      transactionMenu.appendChild(transitionDescription);
      
      let pressTimer;
      let isHolding = false;
      
      const handleDelete = () => {
        userDocRef.collection("transition history").doc(doc.id).delete();
        transitionDescription.remove();
      };
      
      transitionDescription.addEventListener("mousedown", () => {
        pressTimer = setTimeout(() => {
          isHolding = true;
          transitionDescription.style.transition = "background-color 0.5s";
          transitionDescription.style.backgroundColor = "#ed533b";
        }, 1200);
      });
      
      transitionDescription.addEventListener("mouseup", () => {
        clearTimeout(pressTimer);
        if (isHolding) handleDelete();
        isHolding = false;
        transitionDescription.style.backgroundColor = "";
      });
      
      transitionDescription.addEventListener("mouseleave", () => {
        clearTimeout(pressTimer);
        isHolding = false;
        transitionDescription.style.backgroundColor = "";
      });
    });
  });
}

// Format date label
function formatDateLabel(dateObj) {
  const day = String(dateObj.getDate()).padStart(2, "0");
  const month = dateObj.toLocaleString('default', { month: 'short' });
  const year = dateObj.getFullYear();
  return `${day} ${month} ${year}`;
}

// Check if two dates are the same day
function isSameDay(date1, date2) {
  return date1.getDate() === date2.getDate() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getFullYear() === date2.getFullYear();
}
  renderTransitions(); // render on load

// 9️⃣ Render Total Wallet Amount
function renderWalletAmount() {
  const walletElement = document.getElementById("wallet"); // UI element to display wallet amount
  
  // Fetch all transactions from Firestore
  transactionRef.get()
    .then(snapshot => {
      if (snapshot.empty) {
        walletElement.innerHTML = `wallet: <span style="color: green;">₹0</span>`; // Default amount when no transactions exist
        return;
      }
      
      let totalWalletAmount = 0;
      
      snapshot.forEach(doc => {
        const data = doc.data();
        const transactionAmount = parseFloat(data.amount) || 0; // Parse the amount to float
        
        if (data.type === "income") {
          totalWalletAmount += transactionAmount; // Add for income
        } else if (data.type === "expense") {
          totalWalletAmount -= transactionAmount; // Subtract for expense
        }
      });
      
      // Format and display the total wallet amount with the balance colored
      const balanceColor = totalWalletAmount >= 0 ?  "#52854e": "#e82a15";
      walletElement.innerHTML = `Wallet: <span style="color: ${balanceColor};">₹${totalWalletAmount.toLocaleString()}</span>`;
    })
    .catch(error => {
      console.error("Error calculating wallet amount:", error);
      alert("❌ Failed to calculate wallet amount.");
    });
}

// Call the function initially and whenever transactions change
transactionRef.onSnapshot(() => {
  renderWalletAmount();
});

  // 8️⃣ Custom Date Feature
  customDateBtn.addEventListener("click", () => {
    const isVisible = customDateContainer.style.display === "flex";
    if (isVisible) {
      customDateContainer.style.display = "none"; // Hide container
      renderTransitions(); // Render all transaction history
    } else {
      customDateContainer.style.display = "flex"; // Show container
      setDefaultDates(); // Set default dates when the container is visible
    }
  });

  function setDefaultDates() {
    const todayStr = new Date().toISOString().split("T")[0]; // Get today's date in YYYY-MM-DD format
    fromDateInput.value = todayStr; // Set default value for 'fromDate'
    toDateInput.value = todayStr; // Set default value for 'toDate'
  }

  [fromDateInput, toDateInput].forEach(input => {
    input.addEventListener("change", () => {
      renderTransitions(fromDateInput.value, toDateInput.value); // Render transactions based on selected date range
    });
  });
});

